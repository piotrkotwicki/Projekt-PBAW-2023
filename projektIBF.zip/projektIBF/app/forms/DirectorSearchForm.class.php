<?php

namespace app\forms;

class DirectorSearchForm {
	public $surname;
} 