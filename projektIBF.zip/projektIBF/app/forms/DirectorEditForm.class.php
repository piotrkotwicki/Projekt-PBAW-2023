<?php

namespace app\forms;

class DirectorEditForm {
	public $id;
	public $name;
	public $surname;
	public $birthdate;
}