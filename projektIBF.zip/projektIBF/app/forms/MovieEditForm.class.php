<?php

namespace app\forms;

class MovieEditForm {
	public $id;
	public $title;
	public $genre;
	public $premieredate;
    public $iduser;
    public $iddirector;


}