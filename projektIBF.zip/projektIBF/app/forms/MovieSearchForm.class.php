<?php

namespace app\forms;

class MovieSearchForm {
    public $title;
}