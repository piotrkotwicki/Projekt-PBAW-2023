<?php

namespace app\transfer;

class User{
	public $login;
	public $role;
    public $iduser;
	
	public function __construct($login, $role, $iduser){
		$this->login = $login;
		$this->role = $role;
        $this->iduser = $iduser;

	}	
}