<?php

namespace app\controllers;

use app\transfer\User;
use core\App;
use core\SessionUtils;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use app\forms\LoginForm;

class LoginCtrl {

    private $form;

    public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new LoginForm();
    }


    public function validate() {
        $this->form->login = ParamUtils::getFromRequest('login');
        $this->form->pass = ParamUtils::getFromRequest('pass');

        //nie ma sensu walidować dalej, gdy brak parametrów
        if (!isset($this->form->login))
            return false;

        // sprawdzenie, czy potrzebne wartości zostały przekazane
        if (empty($this->form->login)) {
            Utils::addErrorMessage('Nie podano loginu');
        }
        if (empty($this->form->pass)) {
            Utils::addErrorMessage('Nie podano hasła');
        }

//        nie ma sensu walidować dalej, gdy brak wartości
        if (App::getMessages()->isError()){
            Utils::addErrorMessage('Nie można zalogować');
            return false;
        }


        $isAccount = App::getDB()->has("user",[
            "AND" => [
                "login" => $this->form->login,
                "pass" => $this->form->pass
            ]
        ]);

        if($isAccount){

            $record = App::getDB()->get("user", "*" , [
                "login" => $this->form->login,
                "pass" => $this->form->pass
            ]);

            $user = new User($record["login"],$record["role"],$record["iduser"]);
            SessionUtils::store('iduser', $record["iduser"]);
            sessionUtils::storeObject('user', $user);
            RoleUtils::addRole($record["role"]);
        }else{
            Utils::addErrorMessage('Takie konto nie istnieje');
        }



        return !App::getMessages()->isError();
    }

    public function action_loginShow() {
        $this->generateView();
    }

    public function action_login() {
        if ($this->validate()) {
            //zalogowany => przekieruj na główną akcję (z przekazaniem messages przez sesję)
            Utils::addErrorMessage('Poprawnie zalogowano do systemu');
            App::getRouter()->redirectTo("movieList");
        } else {
            //niezalogowany => pozostań na stronie logowania
            $this->generateView();
        }
    }

    public function action_logout() {
        // 1. zakończenie sesji
        session_destroy();
        // 2. idź na stronę główną - system automatycznie przekieruje do strony logowania
        App::getRouter()->redirectTo('generateView');
    }

    public function roleTest() {
        if(RoleUtils::inRole("admin")) {
            return true;
        } elseif(RoleUtils::inRole("user")) {
            return true;
        }  else
            $login = "gość";
        $iduser=null;
        $role = "";
        $user = new User($login, null, null);
        SessionUtils::storeObject('user', $user);
    }

    public function generateView() {
        $this->roleTest();
        App::getSmarty()->assign('user', SessionUtils::loadObject('user', true));
        App::getSmarty()->assign('form', $this->form); // dane formularza do widoku
        App::getSmarty()->display('LoginView.tpl');
    }

    public function action_generateView() {
        $this->roleTest();
        error_reporting(0);
        App::getSmarty()->assign('user', SessionUtils::loadObject('user', true));
        App::getSmarty()->assign('form', $this->form); // dane formularza do widoku
        App::getRouter()->redirectTo('movieList');
    }
}
