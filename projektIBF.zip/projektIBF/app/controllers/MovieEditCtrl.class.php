<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\SessionUtils;
use core\ParamUtils;
use core\Validator;
use app\forms\MovieEditForm;

class MovieEditCtrl {

    private $form; //dane formularza
    private $director;
    public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new MovieEditForm();
    }

    // Walidacja danych przed zapisem (nowe dane lub edycja).
    public function validateSave() {
        //0. Pobranie parametrów z walidacją
        $this->form->id = ParamUtils::getFromRequest('id', true, 'Błędne wywołanie aplikacji');
        $this->form->title = ParamUtils::getFromRequest('title', true, 'Błędne wywołanie aplikacji');
        $this->form->genre = ParamUtils::getFromRequest('genre', true, 'Błędne wywołanie aplikacji');
        $this->form->premieredate = ParamUtils::getFromRequest('premieredate', true, 'Błędne wywołanie aplikacji');
        $this->form->iduser = SessionUtils::load("iduser", true);
        $this->form->iddirector = ParamUtils::getFromRequest('iddirector', true, 'Błędne wywołanie aplikacji');



        if (App::getMessages()->isError())
            return false;

        // 1. sprawdzenie czy wartości wymagane nie są puste
        if (empty(trim($this->form->title))) {
            Utils::addErrorMessage('Wprowadź tytuł');
        }
        if (empty(trim($this->form->genre))) {
            Utils::addErrorMessage('Wprowadź gatunek');
        }
        if (empty(trim($this->form->premieredate))) {
            Utils::addErrorMessage(' Wprowadź date premiery');
        }
        if (empty(trim($this->form->iddirector))) {
            Utils::addErrorMessage(' Wprowadź ID reżysera');
        }

//        if (empty(trim($this->form->iduser))) {
//            Utils::addErrorMessage(' Wprowadź swoje ID');
//        }


        if (App::getMessages()->isError())
            return false;

        // 2. sprawdzenie poprawności przekazanych parametrów

        $d = \DateTime::createFromFormat('Y-m-d', $this->form->premieredate);
        if ($d === false) {
            Utils::addErrorMessage('Zły format daty. Przykład: 2020-12-30');
        }

        return !App::getMessages()->isError();
    }

    //validacja danych przed wyswietleniem do edycji
    public function validateEdit() {
        //pobierz parametry na potrzeby wyswietlenia danych do edycji
        //z widoku listy osób (parametr jest wymagany)
        $this->form->id = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }

    public function action_movieNew() {
        $this->getDirector();
        $this->generateView();
    }

    //wysiweltenie rekordu do edycji wskazanego parametrem 'id'
    public function action_movieEdit() {
        $this->getDirector();


        // 1. walidacja id filmu do edycji
        if ($this->validateEdit()) {
            try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $record = App::getDB()->get("movie", "*", [
                    "idmovie" => $this->form->id
                ]);


                // 2.1 jeśli osoba istnieje to wpisz dane do obiektu formularza
                $this->form->idmovie = $record['idmovie'];
                $this->form->title = $record['title'];
                $this->form->genre = $record['genre'];
                $this->form->premieredate = $record['premieredate'];
                $this->form->iduser = $record['iduser'];
                $this->form->iddirector = $record['iddirector'];

            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        // 3. Wygenerowanie widoku
        $this->generateView();
    }
public function getDirector(){
        $this->director=App::getDB()->select("director", [
            "iddirector",
            "name",
            "surname"
    ]);
}
    public function action_movieDelete() {
        // 1. walidacja id osoby do usuniecia
        if ($this->validateEdit()) {

            try {
                // 2. usunięcie rekordu
                App::getDB()->delete("movie", [
                    "idmovie" => $this->form->id
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        // 3. Przekierowanie na stronę listy osób
        App::getRouter()->forwardTo("movieList");
    }

    public function action_movieSave() {
        $this->getDirector();

        // 1. Walidacja danych formularza (z pobraniem)
        if ($this->validateSave()) {
            // 2. Zapis danych w bazie
            try {

                //2.1 Nowy rekord
                if ($this->form->id == '') {
                        App::getDB()->insert("movie", [
                            "title" => $this->form->title,
                            "genre" => $this->form->genre,
                            "premieredate" => $this->form->premieredate,
                            "iduser" => SessionUtils::load("iduser", true),
                            "iddirector" => $this->form->iddirector

                        ]);
                } else {
                    //2.2 Edycja rekordu o danym ID
                    App::getDB()->update("movie", [
                        "title" => $this->form->title,
                        "genre" => $this->form->genre,
                        "premieredate" => $this->form->premieredate,
                        "iduser" => SessionUtils::load("iduser", true),
                        "iddirector" => $this->form->iddirector
                            ], [
                        "idmovie" => $this->form->id
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }

            // 3b. Po zapisie przejdź na stronę listy osób (w ramach tego samego żądania http)
            App::getRouter()->forwardTo('movieList');
        } else {
            // 3c. Gdy błąd walidacji to pozostań na stronie
            $this->generateView();
        }
    }

    public function generateView() {
        App::getSmarty()->assign('director', $this->director);
        App::getSmarty()->assign('user', SessionUtils::loadObject('user', true));
        App::getSmarty()->assign('form', $this->form); // dane formularza dla widoku
        App::getSmarty()->display('MovieEdit.tpl');
    }

}
