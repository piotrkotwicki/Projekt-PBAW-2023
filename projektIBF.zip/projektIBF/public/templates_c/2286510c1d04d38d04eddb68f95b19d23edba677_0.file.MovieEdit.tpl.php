<?php
/* Smarty version 4.3.0, created on 2023-07-02 21:56:10
  from 'C:\xampp\htdocs\projektIBF\app\views\MovieEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_64a1d65a0ccdf4_39030462',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2286510c1d04d38d04eddb68f95b19d23edba677' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projektIBF\\app\\views\\MovieEdit.tpl',
      1 => 1688320548,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a1d65a0ccdf4_39030462 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_105745640764a1d65a0c6489_28849750', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_176469159464a1d65a0c7452_42597435', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'style'} */
class Block_105745640764a1d65a0c6489_28849750 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_105745640764a1d65a0c6489_28849750',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" href="../assets/css/main.css" />
    <noscript><link rel="stylesheet" href="../assets/css/noscript.css" /></noscript>
<?php
}
}
/* {/block 'style'} */
/* {block 'top'} */
class Block_176469159464a1d65a0c7452_42597435 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_176469159464a1d65a0c7452_42597435',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane filmu</legend>
		<div class="pure-control-group">
            <label for="title">tytuł</label>
            <input id="title" type="text" placeholder="tytuł" name="title" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->title;?>
">
        </div>
		<div class="pure-control-group">
            <label for="genre">gatunek</label>
            <input id="genre" type="text" placeholder="gatunek" name="genre" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->genre;?>
">
        </div>
		<div class="pure-control-group">
            <label for="premieredate">data premiery</label>
            <input id="premieredate" type="text" placeholder="data premiery" name="premieredate" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->premieredate;?>
">
        </div>
		<div class="pure-controls">
			<input type="submit" class="pure-button pure-button-primary" value="Zapisz"/>
			<a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieList">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
