<?php
/* Smarty version 4.3.0, created on 2023-07-09 21:25:01
  from 'C:\xampp\htdocs\projektIBF\app\views\MovieEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_64ab098d34f676_63478223',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2286510c1d04d38d04eddb68f95b19d23edba677' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projektIBF\\app\\views\\MovieEdit.tpl',
      1 => 1688930698,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ab098d34f676_63478223 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16901665164ab098d165505_45326020', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_108835946164ab098d1663c2_31144453', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'style'} */
class Block_16901665164ab098d165505_45326020 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_16901665164ab098d165505_45326020',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" href="../assets/css/main.css" />
    <noscript><link rel="stylesheet" href="../assets/css/noscript.css" /></noscript>
<?php
}
}
/* {/block 'style'} */
/* {block 'top'} */
class Block_108835946164ab098d1663c2_31144453 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_108835946164ab098d1663c2_31144453',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane filmu</legend>
		<div class="pure-control-group">
            <label for="title">tytuł</label>
            <input id="title" type="text" placeholder="tytuł" name="title" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->title;?>
">
        </div>
		<div class="pure-control-group">
            <label for="genre">gatunek</label>
            <input id="genre" type="text" placeholder="gatunek" name="genre" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->genre;?>
">
        </div>
		<div class="pure-control-group">
            <label for="premieredate">data premiery</label>
            <input id="premieredate" type="text" placeholder="data premiery" name="premieredate" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->premieredate;?>
">
        </div>





        <div class="pure-control-group">
            <label for="iddirector">reżyser</label>
            <select id="iddirector" type="text" placeholder="reżyser" name="iddirector" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->iddirector;?>
">
                <option disabled hidden selected value> -- Wybierz opcję z listy -- </option>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['director']->value, 'd');
$_smarty_tpl->tpl_vars['d']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->do_else = false;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['d']->value['iddirector'];?>
"><?php echo $_smarty_tpl->tpl_vars['d']->value['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['d']->value['surname'];?>
</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </select>
        </div>
		<div class="pure-controls">
			<input type="submit" class="pure-button pure-button-primary" value="Zapisz"/>
			<a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieList">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
