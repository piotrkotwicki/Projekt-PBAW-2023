<?php
/* Smarty version 4.3.0, created on 2023-07-09 22:13:58
  from 'C:\xampp\htdocs\projektIBF\app\views\MovieList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_64ab1506d3b8b9_09480849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33497c22d77b52638e43add5139d966095e50188' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projektIBF\\app\\views\\MovieList.tpl',
      1 => 1688933482,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ab1506d3b8b9_09480849 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_111438136764ab1506ca66f4_39512826', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_104114302164ab1506ca71c3_48159505', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_210056156164ab1506d29ce8_19574577', 'bottom');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'style'} */
class Block_111438136764ab1506ca66f4_39512826 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_111438136764ab1506ca66f4_39512826',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<link rel="stylesheet" href="../assets/css/main.css" />
	<noscript><link rel="stylesheet" href="../assets/css/noscript.css" /></noscript>
<?php
}
}
/* {/block 'style'} */
/* {block 'top'} */
class Block_104114302164ab1506ca71c3_48159505 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_104114302164ab1506ca71c3_48159505',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<header class="major">
				<h2>IBF-Internetowa Baza Filmów</h2>
				<p>Autor: Piotr Kotwicki</p>
				<p>Jesteś <?php echo $_smarty_tpl->tpl_vars['user']->value->login;
if ($_smarty_tpl->tpl_vars['user']->value->login != "gość") {?>, twoja rola to <?php echo $_smarty_tpl->tpl_vars['user']->value->role;
}?></p>
			</header>
			<section>
				<p><span class="image left"><img src="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['rel_url'][0], array( array('action'=>"images/zdjecie1.jpg"),$_smarty_tpl ) );?>
" width="500" height="250" alt="" /></span>IBF czyli Internetowa Baza Filmów.<strong> Jedna z największych polskich internetowych baz z filmami. Film to wspaniała dziedzina sztuki, można ją konsumować na różne sposoby. W kinie, w telewizji, na ekranie laptopa, możemy to robić gdzie chcemy i jak chcemy. Dzięki temu w naszym kraju pojawiło się tyle kinomanów. Właśnie dla takich ludzi powstał ten portal. Można tu sprawdzić informację na temat swoich ulubionych produkcji, aktorów oraz reżyserów. Dzięki IBF można też  znależć inspirację do poznania nowych pozycji spośród tych wymienionych w naszej bazie. Miłych seansów wszystkim użytkownikom :)</p>
			</section>

		</div>
	</div>

	<div class="bottom-margin">
		<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieList">
			<legend>Opcje wyszukiwania</legend>
			<fieldset>
				<input type="text" placeholder="tytuł" name="sf_title" value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->title;?>
" /><br />
				<button type="submit" class="pure-button pure-button-primary">Filtruj</button>
			</fieldset>
		</form>
	</div>

<?php
}
}
/* {/block 'top'} */
/* {block 'bottom'} */
class Block_210056156164ab1506d29ce8_19574577 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_210056156164ab1506d29ce8_19574577',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<div class="bottom-margin">
		<a class="pure-button button-success" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieNew">+ Nowy film</a>
	</div>

	<table id="tab_film" class="pure-table pure-table-bordered">
		<thead>
		<tr>
			<th>tytuł</th>
			<th>gatunek</th>
			<th>data premiery</th>
			<th>autor rekordu</th>
			<th>reżyser</th>
			<th>opcje</th>
		</tr>
		</thead>
		<tbody>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['film']->value, 'f');
$_smarty_tpl->tpl_vars['f']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['f']->value) {
$_smarty_tpl->tpl_vars['f']->do_else = false;
?>
			<tr><td><?php echo $_smarty_tpl->tpl_vars['f']->value["title"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["genre"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["premieredate"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["login"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["name"];?>
 <?php echo $_smarty_tpl->tpl_vars['f']->value["surname"];?>
</td><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieEdit/<?php echo $_smarty_tpl->tpl_vars['f']->value['idmovie'];?>
">Edytuj</a>&nbsp;<a class="button-small pure-button button-warning" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieDelete/<?php echo $_smarty_tpl->tpl_vars['f']->value['idmovie'];?>
">Usuń</a></td></tr>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</tbody>
	</table>

<?php
}
}
/* {/block 'bottom'} */
}
