<?php
/* Smarty version 4.3.0, created on 2023-07-02 21:46:36
  from 'C:\xampp\htdocs\projektIBF\app\views\MovieList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_64a1d41c8d90c6_08994427',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33497c22d77b52638e43add5139d966095e50188' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projektIBF\\app\\views\\MovieList.tpl',
      1 => 1688320548,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a1d41c8d90c6_08994427 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_144370793764a1d41c8cac86_71546406', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_177989742064a1d41c8cb8f1_48558041', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_179485841764a1d41c8cfb91_50361639', 'bottom');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'style'} */
class Block_144370793764a1d41c8cac86_71546406 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_144370793764a1d41c8cac86_71546406',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<link rel="stylesheet" href="../assets/css/main.css" />
	<noscript><link rel="stylesheet" href="../assets/css/noscript.css" /></noscript>
<?php
}
}
/* {/block 'style'} */
/* {block 'top'} */
class Block_177989742064a1d41c8cb8f1_48558041 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_177989742064a1d41c8cb8f1_48558041',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<header class="major">
				<h2>IBF-Internetowa Baza Filmów</h2>
				<p>Autor: Piotr Kotwicki</p>
			</header>
			<section>
				<p><span class="image left"><img src="images/zdjecie1.jpg" width="500" height="250" alt="" /></span>IBF czyli Internetowa Baza Filmów Jedna z największych polskich <strong> internetowych baz z filmami Film to wspaniała dziedzina sztuki, można ją konsumować na różne sposoby. W kinie, w telewizji, na ekranie laptopa, możemy to robić gdzie chcemy i jak chcemy. Dzięki temu w naszym kraju pojawiło się tyle kinomanów. Właśnie dla takich ludzi powstał ten portal. Dzięki niemu można sprawdzić informację na temat swoich ulubionych produkcji, aktorów oraz reżyserów. Można też wśród wymienionych pozycji znależć inspirację do poznania nowych pozycji Miłych seansów wszystkim użytkownikom :)</p>
			</section>

		</div>
	</div>

	<div class="bottom-margin">
		<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieList">
			<legend>Opcje wyszukiwania</legend>
			<fieldset>
				<input type="text" placeholder="tytuł" name="sf_title" value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->title;?>
" /><br />
				<button type="submit" class="pure-button pure-button-primary">Filtruj</button>
			</fieldset>
		</form>
	</div>

<?php
}
}
/* {/block 'top'} */
/* {block 'bottom'} */
class Block_179485841764a1d41c8cfb91_50361639 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_179485841764a1d41c8cfb91_50361639',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<div class="bottom-margin">
		<a class="pure-button button-success" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
movieNew">+ Nowy film</a>
	</div>

	<table id="tab_film" class="pure-table pure-table-bordered">
		<thead>
		<tr>
			<th>tytuł</th>
			<th>gatunek</th>
			<th>data premiery</th>
			<th>opcje</th>
		</tr>
		</thead>
		<tbody>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['film']->value, 'f');
$_smarty_tpl->tpl_vars['f']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['f']->value) {
$_smarty_tpl->tpl_vars['f']->do_else = false;
?>
			<tr><td><?php echo $_smarty_tpl->tpl_vars['f']->value["title"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["genre"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['f']->value["premieredate"];?>
</td><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieEdit/<?php echo $_smarty_tpl->tpl_vars['f']->value['idmovie'];?>
">Edytuj</a>&nbsp;<a class="button-small pure-button button-warning" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
movieDelete/<?php echo $_smarty_tpl->tpl_vars['f']->value['idmovie'];?>
">Usuń</a></td></tr>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</tbody>
	</table>

<?php
}
}
/* {/block 'bottom'} */
}
