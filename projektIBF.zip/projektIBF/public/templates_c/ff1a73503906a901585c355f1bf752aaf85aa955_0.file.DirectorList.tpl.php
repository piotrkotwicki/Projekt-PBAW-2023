<?php
/* Smarty version 4.3.0, created on 2023-07-09 22:14:37
  from 'C:\xampp\htdocs\projektIBF\app\views\DirectorList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_64ab152dcdbaf0_85798258',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff1a73503906a901585c355f1bf752aaf85aa955' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projektIBF\\app\\views\\DirectorList.tpl',
      1 => 1688933464,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ab152dcdbaf0_85798258 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_104128915764ab152dcbfcc7_14155250', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_28982453764ab152dcc1397_36823546', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_208459531464ab152dccbe21_22122587', 'bottom');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'style'} */
class Block_104128915764ab152dcbfcc7_14155250 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_104128915764ab152dcbfcc7_14155250',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<link rel="stylesheet" href="../assets/css/main.css" />
	<noscript><link rel="stylesheet" href="../assets/css/noscript.css" /></noscript>
<?php
}
}
/* {/block 'style'} */
/* {block 'top'} */
class Block_28982453764ab152dcc1397_36823546 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_28982453764ab152dcc1397_36823546',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<header class="major">
				<h2>IBF-Internetowa Baza Filmów</h2>
				<p>Autor: Piotr Kotwicki</p>
				<p>Jesteś <?php echo $_smarty_tpl->tpl_vars['user']->value->login;
if ($_smarty_tpl->tpl_vars['user']->value->login != "gość") {?>, twoja rola to <?php echo $_smarty_tpl->tpl_vars['user']->value->role;
}?></p>
			</header>
			<section>
				<p><span class="image left"><img src="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['rel_url'][0], array( array('action'=>"images/zdjecie1.jpg"),$_smarty_tpl ) );?>
" width="500" height="250" alt="" /></span>IBF czyli Internetowa Baza Filmów.<strong> Jedna z największych polskich internetowych baz z filmami. Film to wspaniała dziedzina sztuki, można ją konsumować na różne sposoby. W kinie, w telewizji, na ekranie laptopa, możemy to robić gdzie chcemy i jak chcemy. Dzięki temu w naszym kraju pojawiło się tyle kinomanów. Właśnie dla takich ludzi powstał ten portal. Można tu sprawdzić informację na temat swoich ulubionych produkcji, aktorów oraz reżyserów. Dzięki IBF można też  znależć inspirację do poznania nowych pozycji spośród tych wymienionych w naszej bazie. Miłych seansów wszystkim użytkownikom :)</p>
			</section>

		</div>
	</div>

<div class="bottom-margin">
<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
directorList">
	<legend>Opcje wyszukiwania</legend>
	<fieldset>
		<input type="text" placeholder="nazwisko" name="sf_surname" value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->surname;?>
" /><br />
		<button type="submit" class="pure-button pure-button-primary">Filtruj</button>
	</fieldset>
</form>
</div>	

<?php
}
}
/* {/block 'top'} */
/* {block 'bottom'} */
class Block_208459531464ab152dccbe21_22122587 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_208459531464ab152dccbe21_22122587',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<a class="pure-button button-success" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
directorNew">+ Nowy reżyser</a>
</div>	

<table id="tab_people" class="pure-table pure-table-bordered">
<thead>
	<tr>
		<th>imię</th>
		<th>nazwisko</th>
		<th>data ur.</th>
		<th>autor rekordu</th>
		<th>opcje</th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['human']->value, 'h');
$_smarty_tpl->tpl_vars['h']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['h']->value) {
$_smarty_tpl->tpl_vars['h']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['h']->value["name"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['h']->value["surname"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['h']->value["birthdate"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['h']->value["login"];?>
</td><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
directorEdit/<?php echo $_smarty_tpl->tpl_vars['h']->value['iddirector'];?>
">Edytuj</a>&nbsp;<a class="button-small pure-button button-warning" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
directorDelete/<?php echo $_smarty_tpl->tpl_vars['h']->value['iddirector'];?>
">Usuń</a></td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table>

<?php
}
}
/* {/block 'bottom'} */
}
