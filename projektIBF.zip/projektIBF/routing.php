<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('generateView'); // akcja/ścieżka domyślna
App::getRouter()->setLoginRoute('login'); // akcja/ścieżka na potrzeby logowania (przekierowanie, gdy nie ma dostępu)

Utils::addRoute('directorList',    'DirectorListCtrl');
Utils::addRoute('movieList',    'MovieListCtrl');
Utils::addRoute('generateView',         'LoginCtrl');
Utils::addRoute('loginShow',     'LoginCtrl');
Utils::addRoute('login',         'LoginCtrl');
Utils::addRoute('logout',        'LoginCtrl');
Utils::addRoute('movieNew',     'MovieEditCtrl',	['user','admin']);
Utils::addRoute('movieEdit',    'MovieEditCtrl',	['user','admin']);
Utils::addRoute('movieSave',    'MovieEditCtrl',	['user','admin']);
Utils::addRoute('movieDelete',  'MovieEditCtrl',	['admin']);
Utils::addRoute('directorNew',     'DirectorEditCtrl',	['user','admin']);
Utils::addRoute('directorEdit',    'DirectorEditCtrl',	['user','admin']);
Utils::addRoute('directorSave',    'DirectorEditCtrl',	['user','admin']);
Utils::addRoute('directorDelete',  'DirectorEditCtrl',	['admin']);